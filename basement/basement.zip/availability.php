<?php
include_once("includes/sql_connect.php");
$today=date("Y-m-d");
$roms=array("东厅","西厅","中厅");
$days=array('0','1','2','3','4','5','6','7','8','9');
echo '<head>';
echo '<link rel="stylesheet" href="includes/style.css" type="text/css" >';
echo '</head>';
echo '<h1>信息科学与技术学院地下室预约记录</h1>';
echo '<table name="basement_status" id="basement_status" border="1" class="collapse">';
echo '<div class="date"><tr><td></td>';

foreach ($days as $day) {
	$date=date("Y-m-d",strtotime("+$day day"));
	echo '<td>'.$date.'</td>';
}
	echo '</tr>';

foreach ($roms as $rom) {
	echo '<tr><td>'.$rom.'</td>';
	foreach ($days as $day) {
	$date=date("Y-m-d",strtotime("+$day day"));
	echo '<td>';
	$q="SELECT team_name,start,end FROM register WHERE date='$date' AND rom='$rom' order by start";
	$r=@mysqli_query($mysql,$q);
	if($r){
	while($row=mysqli_fetch_array($r,MYSQLI_ASSOC)){
		//var_dump($row);
		$time=mktime((int)($row['start']/6),($row['start']%6)*10,0);
		$start_time=date('H:i',$time);
		$time=mktime((int)($row['end']/6),($row['end']%6)*10,0);
		$end_time=date('H:i',$time);
		echo '【'.$row['team_name'].'】'.$start_time.'~'.$end_time.'<br>';
			}
		}
	echo '</td>';
	}
	echo "</tr>";

}
echo '<br>';
//include_once("register.html");
?>
